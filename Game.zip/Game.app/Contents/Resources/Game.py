### GAME ####

### IMPORT ###
import cmd # 
import textwrap # 
import sys
import os
import time
import random #

### TEXT EFFECT FUNCTION ###
def texteffect(string, n = 0.05):
    """
    
    """
    q = string
    for character in q:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(n)


### SET SCREEN WIDTH ###
screen_width = 100


####################
### MENU SCREENS ###
####################

### TITLE SCREEN SELECTIONS FUNCTION ###
def title_screen_selections():
    """
    
    """
    option = ""
    while option.lower not in ["help", "im a bitch", "play"]:
        print("Please enter play, im a bitch, or quit")
        option = input("> ")
        if option.lower() == "play":
            setup_game()
        elif option.lower() == "im a bitch":
            help_menu()
        elif option.lower() == "quit":
            sys.exit()
            
####################            
### TITLE SCREEN ###                   
def title_screen():
    """
    
    """
    #os.system('cls')#
    print('\n################################')
    print('###      Gwen Simulator      ###')      
    print('################################')      
    print(' -            .Play.           - ')
    print(' -         .Im a Bitch.        - ')
    print(' -            .Quit.           - ')
    print('################################\n') 
    title_screen_selections()

#################   
### HELP MENU ###   
def help_menu():
    """
    
    """
    print('\n##################################################')
    print('###############     Bitch Menu     ##############')  
    print('##################################################')
    print(' Type move or examine for each turn')      
    print(' If moving, type up, down, left, or right')
    print(' If examining, you may need to answer yes or no')
    print('##################################################\n')
    title_screen_selections()
    
    
    
  
####################
### GAME BACKEND ###
####################
       
    ### PLAYER SET UP ###
class player:
    def __init__(self):
        self.name = ''
        self.job = ''
        self.hp = 0 #
        self.pp = 0 #
        self.status_effects = [] # 
        self.location = 'a1'
        self.haskey = False
        self.hasmanual = False
        self.specialmove = ''
        self.gameover = False        
myPlayer = player()

    
### EXAMPLE OF MAP ###    
    
"""
    
    A   B   C
  -------------
1 |   |   |   |
  -------------
2 |   |   |   |
  -------------
3 |   |   |   |
  -------------

  
"""
    
### FUNCTION TO PRINT MAP ###
#gay little monkey
def printmap():
    """
    Prints map (3x3 grid) based on player location
    """
    print("    A   B   C ")
    print("  -------------")
    if myPlayer.location == 'a1':
        print("1 | x |   |   |")
    elif myPlayer.location == 'b1':
        print("1 |   | x |   |")
    elif myPlayer.location == 'c1':
        print("1 |   |   | x |")
    else:
        print("1 |   |   |   |")
    print("  -------------")
    if myPlayer.location == 'a2':
        print("2 | x |   |   |")
    elif myPlayer.location == 'b2':
        print("2 |   | x |   |")
    elif myPlayer.location == 'c2':
        print("2 |   |   | x |")
    else:
        print("2 |   |   |   |")
    print("  -------------")
    if myPlayer.location == 'a3':
        print("3 | x |   |   |")
    elif myPlayer.location == 'b3':
        print("3 |   | x |   |")
    elif myPlayer.location == 'c3':
        print("3 |   |   | x |")
    else:
        print("3 |   |   |   |")
    print("  -------------")


### CREATING ZONES FOR MAP ###
ZONENAME = ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'

UP = 'up','north'
DOWN = 'down','south'
LEFT = 'left','west'
RIGHT = 'right','east'    


########################################
### DICTIONARY WITH ZONE INFORMATION ###
### EACH ZONE IS ONE SPOT ON THE MAP ###
### MAP IS 3X3 GRID  =  9 ZONES ########
########################################
zone_map = {
    'a1':{
        ZONENAME: 'Bedroom',
        DESCRIPTION: 'You wake up in your bed groggy from the 15 hours of sleep. You ponder taking onother nap ',
        EXAMINATION: '',
        UP: '',
        DOWN: 'a2',
        LEFT: '',
        RIGHT: 'b1'   
            },
    'b1':{
        ZONENAME: 'closet',
        DESCRIPTION: 'You open the door to your enormous closet and hear and feint scratching',
        EXAMINATION: "Oh its just you Jack says. i thought you were the other one. i dont know what it is hes doing but its no good you need to find him.\nill terach you what you need to know but it wont be free.",
        UP: '',
        DOWN: 'b2',
        LEFT: 'a1',
        RIGHT: 'c1'         
            },    
    'c1':{
        ZONENAME: 'Office',
        DESCRIPTION: 'the office That sam asked you to stay out because he has a very impoirtant video call.',
        EXAMINATION: 'Should i go in even though i promised not to?',
        UP: '',
        DOWN: 'c2',
        LEFT: 'b1',
        RIGHT: ''
            },
            
    'a2':{
        ZONENAME: 'Ben and Bethanys house',
        DESCRIPTION: 'You walk throught the front door without knocking and ben and bethany are inside watching malcom in the middle. you feintly overhear them talkming about how theyre worried about sam.',
        EXAMINATION: 'oh hey there dint know you were just walking into peoples houses now we were just watching malcom in the middle.',
        UP: 'a1',
        DOWN: 'a3',
        LEFT: '',
        RIGHT: 'b2'         
            },
    'b2':{
        ZONENAME: 'Mifflin High',
        DESCRIPTION: 'you walk into the front entrance of mifflin high school and see all your friends talking.',
        EXAMINATION: 'you walk up to them and say hi',
        UP: 'b1',
        DOWN: 'b3',
        LEFT: 'a2',
        RIGHT: 'c2'      
            },    
    'c2':{
        ZONENAME: 'Gay Club Entance',
        DESCRIPTION: 'You are outside of the new gayclub that just opened up. theres a long line of poeple outside',
        EXAMINATION: 'at the front of the line you see a bouncer letting poeple in. You walk up to him but before youcan even say anything he start tearing your outift apart. you leave in tears before you can even get a word out.',
        UP: 'c1',
        DOWN: 'c3',
        LEFT: 'b2',
        RIGHT: ''         
            },
            
    'a3':{
        ZONENAME: 'Gay Store',
        DESCRIPTION: 'you walk up to the brightest thing youve ever seen. you put on sunglasses. as you alk closer you see the large crowd of poeple. all you can make out are the yaas queens and slaaays',
        EXAMINATION: 'you walk inside and look around at all the different clothig items.',
        UP: 'a2',
        DOWN: '',
        LEFT: '',
        RIGHT: 'b3'         
            },
    'b3':{
        ZONENAME: 'Back Alley',
        DESCRIPTION: 'you find yourself in a sketchy looking back alley.',
        EXAMINATION: 'you see a bum insisting hes a security guard asking for a 50 dollar covercharge youre not gonna pay that thats absurd!',
        UP: 'b2',
        DOWN: '',
        LEFT: 'a3',
        RIGHT: 'c3'         
            },    
    'c3':{
        ZONENAME: 'Gay Bar',
        DESCRIPTION: 'you walk into the gay bar and see mostly men grinding on eachother! Blasphemous!!!',
        EXAMINATION: 'you walk up to the bar and inquire about sam the bartender tells you he saw somone who looked like that come in about an hour ago',
        UP: 'c2',
        DOWN: '',
        LEFT: 'b3',
        RIGHT: ''         
            } 
    }
    
    
##############################        
##### GAME FUNCTIONALITY #####
##############################  




### STARTS THE GAME ###    
def setup_game():
    """
    """
    #
    
    ## NAME COLLECTING ##
    texteffect("\nHello, what is your name?\n",0.05)
    player_name = input("> ")
    myPlayer.name = player_name.capitalize()
    
    ## JOB COLLECTING ##
    texteffect("\nWhat class do you want to be: Teacher, F-16 Fighter Pilot, or Heroin Addict?\n",0.05)
    player_job = input("> ").lower()
    valid_jobs = ['teacher', 'f-16 fighter pilot', 'heroin addict']
    if player_job in valid_jobs:
        myPlayer.job = player_job
    while player_job not in valid_jobs:
        texteffect("\nPlease select from: Teacher, F-16 Fighter Pilot, or Heroin Addict.\n",0.05)
        player_job = input("> ").lower()
        if player_job.lower() in valid_jobs:
            myPlayer.job = player_job
            
    ## JOB STATS ##    
    #
    if myPlayer.job == 'Teacher':
        myPlayer.hp = 100
        myPlayer.pp = 50
    elif myPlayer.job == 'F-16 Fighter Pilot':
        myPlayer.hp = 75
        myPlayer.pp = 75
    elif myPlayer.job == 'Heroin Addict':
        myPlayer.hp = 50
        myPlayer.pp = 100
    
    ## JOB PRINT - a vs an ##
    ### 
    
#    if myPlayer.job == '':
#        texteffect("You are an " + player_job + "! " + "You have " + str(myPlayer.hp) + "hp and " + str(myPlayer.pp) + "pp.\n\n",0.05)
#    elif myPlayer.job == '' or '':
#        texteffect("You are a " + player_job + "! " + "You have " + str(myPlayer.hp) + "hp and " + str(myPlayer.pp) + "pp.\n\n",0.05)
    
    ## INTRO ##
    texteffect("\nWelcome " + myPlayer.name + ", the " + player_job + ".\n",0.05)
    texteffect("Good luck with this shit.\n",0.05)
    texteffect("Your goal is to survive\n\n\n\n\n",0.08)
        
    
    #os.system('cls') #
    print("#############################")
    print("#  Entering The Thunderdome #")
    print("#############################")
    texteffect("\n\n\n\n",.3)
          
    movement_handler(myPlayer.location)
    main_game_loop()
    
def main_game_loop():
    """
    The whole game runs through this function
    calls prompt which then calls the move or examine functions
    
    I wonder if I could conDense some of these function? What is best practice?
    """
    turncount = 0
    while myPlayer.gameover is False:
        prompt()
        turncount += 1
    texteffect("\nHopefully, you enjoyed the game. It took you " + str(turncount) +" turns to finish the game!\nYou will soon return to the title screen.\n3... 2... 1...\n\n\n",.05)
    title_screen()
  
    
##########################    
### GAME INTERACTIVITY ###
##########################
    
### SOME VARIABLES ###
c2_gateopen = False
b3_pathblock = True
# 
# 
 
    
### FUNCTION FOR EACH "TURN" ###
def prompt():
    """
    This function creates each turn for the game.
    Depending on user input it directs to proper function
    """
    print('\n' + '============================')
    print("What would you like to do?\nEnter move, examine, or quit.")
    action = input ("> ")
    acceptable_actions = ['move', 'm', 'go', 'travel', 'walk', 'examine', 'e','inspect', 'interact', 'look', 'quit']
    while action.lower() not in acceptable_actions:
        print("Unknown action, please try again.\n")
        action = input ("> ")
    if action.lower() == 'quit':
        sys.exit()
    elif action.lower() in ['move', 'm', 'go', 'travel', 'walk']:
        player_move(action.lower())
    elif action.lower() in ['examine', 'e', 'inspect', 'interact', 'look']:
        player_examine(action.lower())

### PRINTS PLAYER LOCATION ###
def movement_handler(destination):
    """
    When the player moves, this function print out everything properly
    """
    myPlayer.location = destination
    print('\n' + ('#' * (4 + len(zone_map[myPlayer.location][ZONENAME]))))
    print('# ' + zone_map[myPlayer.location][ZONENAME] + ' #')
    print(('#' * (4 + len(zone_map[myPlayer.location][ZONENAME])))) 
    #print ('########################')
    print ("You are now in block " + destination + '.\n')
    printmap()
    print ('\n' + 'x ' + zone_map[myPlayer.location][DESCRIPTION])
        
### HANDLES PLAYER MOVEMENT ###           
def player_move(moveAction):
    """
    This function handles player movement
    """
    properdirection = False
    while properdirection == False:
        ask = "Where would you like to move to?\n"
        dest = input(ask)
        if dest not in ['up', 'north', 'down', 'south', 'left', 'west', 'right', 'east']:
            print("Invalid direction, please use up, down, left, or right.")  
            
        elif dest in ['up', 'north']:
            destination = zone_map[myPlayer.location][UP]
            if destination == 'c3' and c2_gateopen == False:
                print("The bouncer is mean muggin you.\n\'Not a chance\'")
                prompt()
            elif destination == '':
                print("You cannot move that way, please try again.")
            else:
                properdirection = True
                movement_handler(destination)
        elif dest in ['down', 'south']:
            destination = zone_map[myPlayer.location][DOWN]
            if destination == 'c3' and c2_gateopen == False:
                print("The bouncer is mean muggin you.\n\'Not a chance\'")
                prompt()
            elif destination == '':
                print("You cannot move that way, please try again.")
            else:
                properdirection = True
                movement_handler(destination)
        elif dest in ['left', 'west']:
            destination = zone_map[myPlayer.location][LEFT]
            if destination == 'b3' and b3_pathblock == True:
                print("WOAH WOAH WOAH BUDDY youre not getting in unless you pay me my 50 dollars!!!.")   
                prompt()
            elif destination == '':
                print("You cannot move that way, please try again.")
            else:
                properdirection = True
                movement_handler(destination)
        elif dest in ['right', 'east']:
            destination = zone_map[myPlayer.location][RIGHT]
            if destination == 'c3' and b3_pathblock == True:
                print("WOAH WOAH WOAH BUDDY youre not getting in unless you pay me my 50 dollars!!!.")   
                prompt()
            elif destination == '':
                print("You cannot move that way, please try again.")
            else:
                properdirection = True
                movement_handler(destination)
        
### HANDLES PLAYER EXAMINATION ###   
#
            
def player_examine(examineAction):
    """
    This function handles player examination
    A lot of the main game content is inside this function
    """
    ### 
    global c2_gateopen
    global b3_pathblock
    
    print(zone_map[myPlayer.location][EXAMINATION])

###  A1  ###
    if myPlayer.location == 'a1':
        print("You look at the bed and feel yourself starting to give in.")
        homesleep = input("Do you want to take a nap?\n").lower()
        while homesleep not in ['y', 'yes', 'n', 'no']:
            print("Invalid input. Please enter yes or no.") 
            homesleep = input("Do you want to take a nap?\n").lower()
        if homesleep in ['y', 'yes']:
            print("You dream of little hampster driving a kia soul. BEEP BEEP BEEP.\'Ugh still not enough sleep\'")
            if myPlayer.job == 'teacher':
                myPlayer.hp = 100
                myPlayer.pp = 50
            elif myPlayer.job == 'F-16 Fighter Pilot':
                myPlayer.hp = 75
                myPlayer.pp = 75
            elif myPlayer.job == 'heroin addict':
                myPlayer.hp = 50
                myPlayer.pp = 100
        elif homesleep in ['n', 'no']:
                print("Even though its tempting you have things to do no more nappy")
        print("")

###  B1  ###
    elif myPlayer.location == 'b1':
        if myPlayer.specialmove == '':
            if myPlayer.hasmanual == True:
                trainingquestion = input("Do you want to give Jack the cat weed?\n").lower()
                while  trainingquestion not in ['y', 'yes', 'n', 'no']:
                    print("Invalid input. Please enter yes or no.")
                    trainingquestion = input("Do you want to give Jack the cat weedmove?\n").lower()
                if trainingquestion in ['y', 'yes']:
                    if myPlayer.job == 'teacher':
                        myPlayer.specialmove = "Throat Chop"
                        print("alright if anyone ever gives you any trouble just use the good ole throat chop!")
                    elif myPlayer.job == 'F-16 Fighter Pilot':
                        myPlayer.specialmove = "Throat Chop"
                        print("alright if anyone ever gives you any trouble just use the good ole throat chop!")
                    elif myPlayer.job == 'heroin addict':
                        myPlayer.specialmove = "Throat Chop"
                        print("alright if anyone ever gives you any trouble just use the good ole throat chop!")
                elif trainingquestion in ['n', 'no']:
                    print("")
            else:
                print("")
        else: print("What are you still doing here human be on your way! You know " + myPlayer.specialmove + " now!")

###  C1  ###
    elif myPlayer.location == 'c1':
        townhallquestion = input("Do you want to enter Office?\n").lower()
        while townhallquestion not in ['y', 'yes', 'n', 'no']:
            print("Invalid input. Please enter yes or no.") 
            townhallquestion = input("Do you want to enter Office?\n").lower()
        if townhallquestion in ['y', 'yes']:
            print("You enter The Office, it seems Sam isnt in here. You look over and see the Window open surely he didnt jump. after pomdering for a minute you look over to see sams open desk drawer\n")
            townhalldesk = input("Do you search his desk?\n").lower()
            while townhalldesk not in ['y', 'yes', 'n', 'no']:
                print("Invalid input. Please enter yes or no.") 
                townhalldesk = input("Do you search the desk?\n").lower()
            if townhalldesk in ['y', 'yes']:
                print("You find a bag of cat treats l;abeled cat mint with various chinese charectors!")
                myPlayer.hasmanual = True
            elif townhalldesk in ['n', 'no']:
                print("You walk away empty handed like a coward...")   
        elif townhallquestion in ['n', 'no']:
            print("")        

   
###  A2  ### 
    elif myPlayer.location == 'a2':
        if myPlayer.haskey == False:
            askwhyanswer = input("Do you want to pry about what you heard earlier?\n").lower()
            while askwhyanswer not in ['y', 'yes', 'n', 'no']:
                print("Invalid input. Please enter yes or no.") 
                askwhyanswer = input("Do you want to pry about what you heard earlier?\n").lower()
            if askwhyanswer in ['y', 'yes']:
                print("Hes just been having some troubles lately im sure it will pass!")
            elif askwhyanswer in ['n', 'no']:
                print("You just nod and leave without saying a word.")
        elif myPlayer.haskey == True:
            print("Ben and Bethany notice your outfit and suggest you check out the Gay Club!")
                
###  B2  ### 
    elif myPlayer.location == 'b2':
        if myPlayer.haskey == False:
            print("Oh hi we were just talking about the new gay store that just opened up. they have such cute outfits.No offense just some constuctive critisism that outfit is so blegh you might wanna check the Gay Store out")
        else:
            print("i see youve been to the gay store we were just talking about the gay store you look so gay!")
   
###  C2  ### 
    elif myPlayer.location == 'c2':
        if myPlayer.haskey == True:
            if c2_gateopen == True:
                print("The bouncer let you in!")
            else:
                opengateq = input("Do you want to try to prove yourself to the bouncer with your new outfit?\n").lower()
                while opengateq not in ['y', 'yes', 'n', 'no']:
                    print("Invalid input. Please enter yes or no.") 
                    opengateq = input("Do you want to try to prove yourself to the bouncer with your new outfit?\n").lower()
                if opengateq in ['y', 'yes']:
                    c2_gateopen = True
                    print("The bouncer has been impressed!")
                elif opengateq in ['n', 'no']:
                        print("You walk away in shame...")
  
  
###  A3  ### 
    elif myPlayer.location == 'a3':
        if myPlayer.haskey == False:
            haskeyquestion = input("Hi there baby i cant help but notice your terrible outfit can i interest you in the ultramega gay outfit 5000?\n").lower()
            while haskeyquestion not in ['y', 'yes', 'n', 'no']:
                print("Invalid input. please enter yes or no.") 
                haskeyquestion = input("Hi baby i cant help but notice your terrible outfit can i interest you in the ultramega gay outfit 5000?\n").lower()
            if haskeyquestion in ['y', 'yes']:
                myPlayer.haskey = True
                print("It looks great honey 10000 dollars please.")
            elif haskeyquestion in ['n', 'no']:
                print("Your loss honey")

###  B3  ### 
    elif myPlayer.location == 'b3':
        if myPlayer.specialmove == '':
            print("There is a bum to the east blocking trhe back alley to the gay club you ponder taking him out but you arent confidant with your throat choppuing abilities.")
        elif b3_pathblock == True:
            monsterfight = input("There is a bum to the east. Do you to fight the bum?\n").lower()
            while monsterfight not in ['y', 'yes', 'n', 'no']:
                print("Invalid input. Please enter yes or no.") 
                monsterfight = input("Do you to fight the bum?\n").lower()
            if monsterfight in ['y', 'yes']:
                print("You engage the bum and use the special skill Jack taught you, " + myPlayer.specialmove)
                texteffect("It is a tough battle... but... you... prevail! The bum is defeated!",.05)
                b3_pathblock = False
                print("The path has cleared!")
            elif monsterfight in ['n', 'no']:
                print("You leave the bum alone")
        else:
            print("A bum used to sleep here, but some asshole killed him!")
  
###  C3  ### 
    elif myPlayer.location == 'c3':
        test = 0
        print("right as you turn around to go look for sam you see him right there grinding on a MAN! \'its not what it looks like\' says sam \n\'aw who am i kidding you saw me with my balls all over that guy we have to fight this out!")
        testworth = input("Are you ready for this dual?\n").lower()
        while testworth not in ['y', 'yes', 'n', 'no']:
            print("Invalid input. please enter yes or no.") 
            testworth = input("Are you ready for this dual?\n").lower()
        if testworth in ['y', 'yes']:
            if myPlayer.specialmove == '':
                texteffect("You fool you havent even mastered the throat chop yet I WILL CREAM YOU!!! come back when youre ready pussy!\n",.05)
            else:
                texteffect("oh no the throat chop my one weakness!\n",.08)
                test += 1
            if myPlayer.haskey == False:
                texteffect("You are not powerful or influential enough yet! Perhaps you should do talk to the townsfolk at the Square!\n",.05)
            else:
                texteffect("so stylish where did you get those clothes?",.08)
                test += 1           
        elif testworth in ['n', 'no']:
            print("What? you just dont wanna fight me? whats wrong with you fuck it i guess back to grinding this gay guy.")
        if test == 2:
            texteffect("\nin one swift chop you crush sams windpipe he drops to the floor gasping for air while you bust a move. \'Im sorry i didnt mean it i wont be gay anymore i swear. you return home happily ever after. THE END\n",.05)
            myPlayer.gameover = True 
  
    else:
        print("")
        


#######################   
### STARTS THE GAME ###
#######################
        
title_screen()

#######################
